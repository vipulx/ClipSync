const loginOverlay = document.getElementById('loginOverlay');
const appContainer = document.getElementById('appContainer');
const loginForm = document.getElementById('loginForm');
const pinInput = document.getElementById('pinInput');
const loginError = document.getElementById('loginError');
const clipInput = document.getElementById('clipInput');
const sendBtn = document.getElementById('sendBtn');
const timeline = document.getElementById('timeline');
const emptyState = document.getElementById('emptyState');
const toast = document.getElementById('toast');
const toastMsg = document.getElementById('toastMsg');
const logoutBtn = document.getElementById('logoutBtn');
const tagBtn = document.getElementById('tagBtn');
const tagInputWrapper = document.getElementById('tagInputWrapper');
const tagInput = document.getElementById('tagInput');
const activeTagsContainer = document.getElementById('activeTagsContainer');
const filterContainer = document.getElementById('filterContainer');
const fileUpload = document.getElementById('fileUpload');
const uploadProgress = document.getElementById('uploadProgress');
const uploadProgressBar = uploadProgress.querySelector('div');
const autoSyncToggle = document.getElementById('autoSyncToggle');

let socket;
let currentTags = [];
let globallyUsedTags = new Set();
let activeFilter = null;
let allClips = [];

// --- Check Auth State on Load ---
async function checkAuth() {
    try {
        const res = await fetch('/api/check-auth');
        const data = await res.json();
        if (data.authenticated) {
            initApp();
        }
    } catch (e) {
        console.error("Auth check failed", e);
    }
}
checkAuth();

// --- Login Handle ---
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const pin = pinInput.value;
    try {
        const res = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pin })
        });
        const data = await res.json();
        if (data.success) {
            initApp();
        } else {
            loginError.classList.remove('hidden');
            pinInput.value = '';
        }
    } catch (e) {
        loginError.innerText = "Connection error";
        loginError.classList.remove('hidden');
    }
});

logoutBtn.addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' });
    window.location.reload();
});

// --- Init App ---
function initApp() {
    loginOverlay.classList.add('opacity-0', 'pointer-events-none');
    setTimeout(() => loginOverlay.classList.add('hidden'), 300);
    appContainer.classList.remove('hidden');
    
    // Connect socket
    socket = io();
    
    socket.on('connect', () => {
        console.log("Connected to server");
        loadInitialClips();
    });
    
    socket.on('new_clip', (clip) => {
        if (!allClips.find(c => c.id === clip.id)) {
            allClips.unshift(clip);
            updateGloballyUsedTags();
            renderTimeline();
            
            // Only show toast and play sound if not actively typing to avoid annoyance
            if(document.activeElement !== clipInput && !clip.isLocal) {
                showToast("New item synced");
                playHaptic();
            }
        }
    });

    socket.on('delete_clip', (id) => {
        allClips = allClips.filter(c => c.id != id);
        renderTimeline();
    });
    
    socket.on('disconnect', () => {
        console.log("Disconnected from server");
    });
    
    // Start auto sync check if enabled via localStorage memory
    if (localStorage.getItem('clipsync_autosync') === 'true') {
        autoSyncToggle.checked = true;
        startAutoSync();
    }
}

async function loadInitialClips() {
    try {
        const res = await fetch('/api/clips');
        const data = await res.json();
        allClips = data;
        updateGloballyUsedTags();
        renderTimeline();
    } catch (e) {
        console.error("Failed to load clips", e);
    }
}

// --- Smart Detection ---
function detectType(content) {
    const txt = content.trim();
    if (/^https?:\/\/[^\s]+$/.test(txt)) return 'url';
    if (txt.includes('{') && txt.includes('}') || txt.includes('function') || txt.includes('=>') || txt.includes('const ') || txt.includes('let ') || txt.includes('import ') || txt.includes('</div>')) {
        return 'code';
    }
    return 'text';
}

function escapeHTML(str) {
    const div = document.createElement('div');
    div.innerText = str;
    return div.innerHTML;
}

// --- Inputs ---
clipInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendClip();
    }
});

sendBtn.addEventListener('click', sendClip);

function sendClip() {
    const content = clipInput.value.trim();
    if (!content) return;
    
    const type = detectType(content);
    
    const clipData = {
        content,
        type,
        tags: JSON.stringify(currentTags)
    };
    
    socket.emit('add_clip', clipData);
    
    clipInput.value = '';
    currentTags = [];
    renderActiveTags();
}

// --- Tag Input handling ---
tagBtn.addEventListener('click', () => {
    tagInputWrapper.classList.toggle('hidden');
    tagInputWrapper.classList.toggle('flex');
    if(!tagInputWrapper.classList.contains('hidden')) {
        tagInput.focus();
    }
});

tagInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        const tag = tagInput.value.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
        if (tag && !currentTags.includes(tag)) {
            currentTags.push(tag);
            renderActiveTags();
        }
        tagInput.value = '';
    }
});

function renderActiveTags() {
    activeTagsContainer.innerHTML = '';
    currentTags.forEach(tag => {
        const el = document.createElement('div');
        el.className = 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 px-3 py-1 text-xs font-semibold rounded-full flex items-center gap-1';
        el.innerHTML = `
            <span>#${tag}</span>
            <button class="hover:text-red-500 ml-1 focus:outline-none" onclick="removeTag('${tag}')">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        `;
        activeTagsContainer.appendChild(el);
    });
}

window.removeTag = (tag) => {
    currentTags = currentTags.filter(t => t !== tag);
    renderActiveTags();
};

// --- File Upload ---
fileUpload.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
        alert("File too large. Max 5MB allowed.");
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    
    uploadProgress.classList.remove('hidden');
    uploadProgressBar.style.width = '20%';
    
    try {
        const req = new XMLHttpRequest();
        req.upload.addEventListener("progress", function (evt) {
            if (evt.lengthComputable) {
                let percentComplete = evt.loaded / evt.total;
                percentComplete = parseInt(percentComplete * 100);
                uploadProgressBar.style.width = percentComplete + '%';
            }
        });
        
        req.open("POST", "/api/upload", true);
        req.onload = function(e) {
            setTimeout(() => {
                uploadProgress.classList.add('hidden');
                uploadProgressBar.style.width = '0%';
                fileUpload.value = '';
            }, 500);
        };
        req.send(formData);
    } catch (err) {
        console.error("Upload failed", err);
        uploadProgress.classList.add('hidden');
    }
});

// --- Render Timeline ---
function updateGloballyUsedTags() {
    globallyUsedTags.clear();
    allClips.forEach(c => {
        try {
            const tags = JSON.parse(c.tags || '[]');
            tags.forEach(t => globallyUsedTags.add(t));
        } catch(e) {}
    });
    renderFilters();
}

function renderFilters() {
    filterContainer.innerHTML = '';
    const allBtn = document.createElement('button');
    allBtn.className = `px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${activeFilter === null ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900' : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'}`;
    allBtn.innerText = 'All';
    allBtn.onclick = () => { activeFilter = null; renderFilters(); renderTimeline(); };
    filterContainer.appendChild(allBtn);
    
    globallyUsedTags.forEach(tag => {
        const btn = document.createElement('button');
        btn.className = `px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${activeFilter === tag ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400 dark:hover:bg-blue-900/50'}`;
        btn.innerText = '#' + tag;
        btn.onclick = () => { activeFilter = tag; renderFilters(); renderTimeline(); };
        filterContainer.appendChild(btn);
    });
}

function renderTimeline() {
    timeline.innerHTML = '';
    
    let filtered = allClips;
    if (activeFilter) {
        filtered = allClips.filter(c => {
            try { return JSON.parse(c.tags || '[]').includes(activeFilter); } 
            catch(e) { return false; }
        });
    }
    
    if (filtered.length === 0) {
        timeline.appendChild(emptyState);
        emptyState.classList.remove('hidden');
        return;
    }
    emptyState.classList.add('hidden');
    
    filtered.forEach(clip => {
        const d = new Date(clip.timestamp);
        const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        let parsedTags = [];
        try { parsedTags = JSON.parse(clip.tags || '[]'); } catch(e){}
        const tagHTML = parsedTags.map(t => `<span class="text-xs font-semibold text-blue-500 mr-2">#${t}</span>`).join('');

        let contentHTML = '';
        
        if (clip.type === 'url') {
            contentHTML = `
                <div class="flex items-center gap-3 bg-gray-50 dark:bg-gray-900/50 p-3 rounded-xl border border-gray-100 dark:border-gray-800">
                    <div class="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center rounded-lg flex-shrink-0">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                    </div>
                    <div class="overflow-hidden">
                        <a href="${clip.content}" target="_blank" class="text-blue-600 dark:text-blue-400 font-medium hover:underline truncate block">${escapeHTML(clip.content)}</a>
                    </div>
                </div>`;
        } else if (clip.type === 'file') {
            const isImage = clip.content.match(/\.(jpeg|jpg|gif|png|webp)$/i);
            if (isImage) {
                contentHTML = `
                <div class="relative group rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                    <img src="${clip.file_path}" alt="${escapeHTML(clip.content)}" class="max-h-64 object-contain mx-auto w-full">
                    <a href="${clip.file_path}" download="${clip.content}" class="absolute bottom-2 right-2 p-2 bg-black/60 backdrop-blur text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    </a>
                </div>`;
            } else {
                contentHTML = `
                <div class="flex items-center justify-between bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                    <div class="flex items-center gap-3 overflow-hidden">
                        <svg class="w-8 h-8 text-indigo-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        <p class="font-medium text-gray-800 dark:text-gray-200 truncate">${escapeHTML(clip.content)}</p>
                    </div>
                    <a href="${clip.file_path}" download="${clip.content}" class="p-2 bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 rounded-lg hover:bg-indigo-200 dark:hover:bg-indigo-900/50 transition-colors flex-shrink-0">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    </a>
                </div>`;
            }
        } else if (clip.type === 'code') {
            contentHTML = `
                <div class="rounded-xl overflow-hidden shadow-inner font-mono text-sm">
                    <pre><code class="language-javascript">${escapeHTML(clip.content)}</code></pre>
                </div>`;
        } else {
            // plain text
            contentHTML = `
                <div class="p-4 bg-gray-50 dark:bg-gray-900/30 rounded-xl whitespace-pre-wrap font-sans text-gray-700 dark:text-gray-300 border border-transparent hover:border-gray-200 dark:hover:border-gray-800 transition-colors">${escapeHTML(clip.content)}</div>
            `;
        }

        const card = document.createElement('div');
        card.className = "clip-card pl-8 relative group";
        card.id = `clip-${clip.id}`;
        
        // Node marker
        const marker = document.createElement('div');
        marker.className = "absolute left-[-5px] top-4 w-3 h-3 rounded-full border-2 border-white dark:border-darkBg bg-blue-500 shadow z-10";
        card.appendChild(marker);

        card.innerHTML += `
            <div class="bg-white dark:bg-darkCard rounded-2xl p-1 shadow-sm border border-gray-100 dark:border-gray-800 transition-shadow hover:shadow-md">
                <div class="p-3 sm:px-4 flex items-center justify-between border-b border-gray-50 dark:border-gray-800/50">
                    <div class="flex items-center gap-2">
                        <span class="text-xs text-gray-400 font-medium">${timeStr}</span>
                        ${clip.type !== 'text' ? `<span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded text-gray-500 bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">${clip.type}</span>` : ''}
                    </div>
                    <div class="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                        <button class="copyBtn p-1.5 text-gray-400 hover:text-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors" data-content="${escapeHTML(clip.content)}" title="Copy">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                        </button>
                        <button class="deleteBtn p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors" data-id="${clip.id}" title="Delete">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    </div>
                </div>
                <div class="p-3 sm:px-4">
                    ${contentHTML}
                    ${tagHTML ? `<div class="mt-3 flex gap-1">${tagHTML}</div>` : ''}
                </div>
            </div>
        `;
        
        timeline.appendChild(card);
    });

    // Run prism highlighter
    if (window.Prism) Prism.highlightAll();

    // Attach local events
    document.querySelectorAll('.copyBtn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const val = e.currentTarget.getAttribute('data-content');
            // unescape
            const txt = new DOMParser().parseFromString(val, "text/html").documentElement.textContent;
            navigator.clipboard.writeText(txt).then(() => {
                showToast('Copied to clipboard!');
                const cardWrap = e.currentTarget.closest('.bg-white');
                cardWrap.classList.add('copy-success');
                setTimeout(() => cardWrap.classList.remove('copy-success'), 1000);
            });
        });
    });

    document.querySelectorAll('.deleteBtn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const id = e.currentTarget.getAttribute('data-id');
            if (confirm("Delete this snippet?")) {
                await fetch(`/api/clips/${id}`, { method: 'DELETE' });
            }
        });
    });
}

// --- Utilities ---
function showToast(msg) {
    toastMsg.innerText = msg;
    toast.classList.remove('translate-y-20', 'opacity-0');
    setTimeout(() => {
        toast.classList.add('translate-y-20', 'opacity-0');
    }, 3000);
}

function playHaptic() {
    if (navigator.vibrate) navigator.vibrate(50);
}

// --- Auto Sync Feature ---
let autoSyncInterval;
let lastClipboardHash = '';

autoSyncToggle.addEventListener('change', (e) => {
    localStorage.setItem('clipsync_autosync', e.target.checked);
    if (e.target.checked) {
        startAutoSync();
        showToast("Auto Sync enabled. Grant clipboard permissions if prompted.");
    } else {
        stopAutoSync();
    }
});

async function startAutoSync() {
    if (!navigator.clipboard || !navigator.clipboard.readText) return;
    
    // Seed hash so we don't instantly upload what's already there
    try {
        const txt = await navigator.clipboard.readText();
        lastClipboardHash = hashCode(txt);
    } catch(e) {}

    autoSyncInterval = setInterval(async () => {
        // Skip if document is hidden to save resources or if not focused
        if (document.hidden) return;
        
        try {
            const txt = await navigator.clipboard.readText();
            if (!txt) return;
            
            const hash = hashCode(txt);
            if (hash !== lastClipboardHash) {
                lastClipboardHash = hash;
                
                // Avoid recursive loops: make sure this text isn't the same as the last item we received!
                if (allClips.length > 0 && allClips[0].content === txt) return;
                
                const type = detectType(txt);
                
                socket.emit('add_clip', {
                    content: txt,
                    type: type,
                    tags: "[]"
                });
                
                showToast("Auto-synced from local clipboard");
            }
        } catch(e) {
            // Usually permissions error, quietly fail or warn user occasionally
        }
    }, 3000);
}

function stopAutoSync() {
    if (autoSyncInterval) clearInterval(autoSyncInterval);
}

// simple string hash
function hashCode(str) {
    let hash = 0;
    for (let i = 0, len = str.length; i < len; i++) {
        let chr = str.charCodeAt(i);
        hash = (hash << 5) - hash + chr;
        hash |= 0;
    }
    return hash;
}
