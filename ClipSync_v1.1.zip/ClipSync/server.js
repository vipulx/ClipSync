require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const session = require('express-session');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const db = require('./database');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)){
    fs.mkdirSync(uploadsDir);
}

// Global PIN Hash setup
const PIN = process.env.PIN || '1234';
const hashedPIN = bcrypt.hashSync(PIN, 10);

// Setup session middleware
const sessionMiddleware = session({
    secret: process.env.SESSION_SECRET || 'fallback_secret',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, // true if using https locally
        maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(sessionMiddleware);
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

// Configure Multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname)
    }
});
const upload = multer({ 
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

// Middleware to check authentication
const requireAuth = (req, res, next) => {
    if (req.session.authenticated) {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized' });
    }
};

// API Routes
app.post('/api/login', async (req, res) => {
    const { pin } = req.body;
    if (!pin) return res.status(400).json({ error: 'PIN is required' });
    
    const isMatch = await bcrypt.compare(pin.toString(), hashedPIN);
    if (isMatch) {
        req.session.authenticated = true;
        res.json({ success: true });
    } else {
        res.status(401).json({ error: 'Invalid PIN' });
    }
});

app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

app.get('/api/check-auth', (req, res) => {
    if (req.session.authenticated) {
        res.json({ authenticated: true });
    } else {
        res.json({ authenticated: false });
    }
});

app.get('/api/clips', requireAuth, (req, res) => {
    db.all("SELECT * FROM clips ORDER BY timestamp DESC LIMIT 100", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

app.delete('/api/clips/:id', requireAuth, (req, res) => {
    const { id } = req.params;
    db.run("DELETE FROM clips WHERE id = ?", id, function(err) {
        if (err) return res.status(500).json({ error: err.message });
        // Broadcast deletion
        io.emit('delete_clip', id);
        res.json({ success: true, changes: this.changes });
    });
});

app.post('/api/upload', requireAuth, upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
    
    const content = req.body.content && req.body.content.trim() !== '' ? req.body.content : req.file.originalname;
    const type = 'file';
    const tags = req.body.tags || '[]';
    const filePath = '/uploads/' + req.file.filename;
    
    db.run(
        "INSERT INTO clips (content, type, tags, file_path) VALUES (?, ?, ?, ?)",
        [content, type, tags, filePath],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            
            const newClip = {
                id: this.lastID,
                content: content,
                type: type,
                tags: tags,
                file_path: filePath,
                timestamp: new Date().toISOString()
            };
            
            io.emit('new_clip', newClip);
            res.json(newClip);
        }
    );
});

// Socket.IO Setup
io.engine.use(sessionMiddleware);

io.on('connection', (socket) => {
    const req = socket.request;
    // Basic auth check for socket connection
    if (!req.session.authenticated) {
        socket.disconnect();
        return;
    }
    
    console.log('Client connected:', socket.id);
    
    socket.on('add_clip', (data) => {
        const { content, type, tags, file_path } = data;
        const safeTags = tags || '[]';
        
        db.run(
            "INSERT INTO clips (content, type, tags, file_path) VALUES (?, ?, ?, ?)",
            [content, type, safeTags, file_path || null],
            function(err) {
                if (err) {
                    console.error("Error inserting clip", err);
                    return;
                }
                
                const newClip = {
                    id: this.lastID,
                    content: content,
                    type: type,
                    tags: safeTags,
                    file_path: file_path || null,
                    timestamp: new Date().toISOString()
                };
                
                // Broadcast to all clients including sender
                io.emit('new_clip', newClip);
            }
        );
    });
    
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
