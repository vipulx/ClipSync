const loginOverlay = document.getElementById('loginOverlay');
const appContainer = document.getElementById('appContainer');
const loginForm = document.getElementById('loginForm');
const pinInput = document.getElementById('pinInput');
const keypad = document.getElementById('keypad'); // we don't have loginError anymore but we can just use dots animation
const clipInput = document.getElementById('clipInput');
const sendBtn = document.getElementById('sendBtn');
const timeline = document.getElementById('timeline');
const emptyState = document.getElementById('emptyState');
const toast = document.getElementById('toast');
const toastMsg = document.getElementById('toastMsg');
const logoutBtn = document.getElementById('logoutBtn');
const tagBtn = document.getElementById('tagBtn');
const tagInputWrapper = document.getElementById('tagInputWrapper');
const tagInput = document.getElementById('tagInput');
const activeTagsContainer = document.getElementById('activeTagsContainer');
const filterContainer = document.getElementById('filterContainer');
const fileUpload = document.getElementById('fileUpload');
const uploadProgress = document.getElementById('uploadProgress');
const uploadProgressBar = uploadProgress.querySelector('div');
const autoSyncToggle = document.getElementById('autoSyncToggle');
const themeToggleBtn = document.getElementById('themeToggleBtn');
const pasteBtn = document.getElementById('pasteBtn');

const stagedFileContainer = document.getElementById('stagedFileContainer');
const stagedFileName = document.getElementById('stagedFileName');
const removeStagedFileBtn = document.getElementById('removeStagedFileBtn');

const deleteModal = document.getElementById('deleteModal');
const deleteModalContent = document.getElementById('deleteModalContent');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');

let socket;
let currentTags = [];
let globallyUsedTags = new Set();
let activeFilter = null;
let allClips = [];
let stagedFile = null;

// --- Theme Toggle ---
if (localStorage.theme === 'light' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: light)').matches)) {
    document.documentElement.classList.remove('dark');
} else {
    document.documentElement.classList.add('dark');
}

themeToggleBtn.addEventListener('click', () => {
    document.documentElement.classList.toggle('dark');
    if (document.documentElement.classList.contains('dark')) {
        localStorage.theme = 'dark';
    } else {
        localStorage.theme = 'light';
    }
});

// --- Quick Paste ---
pasteBtn.addEventListener('click', async () => {
    try {
        const text = await navigator.clipboard.readText();
        clipInput.value += text;
        clipInput.focus();
    } catch (err) {
        showToast("Failed to read clipboard natively.");
    }
});

// --- Passcode Login Screen Logic ---
const passcodeDots = Array.from(document.getElementById('passcodeDots').children);
const keypadBtns = document.querySelectorAll('.keypad-btn');
let enteredPin = "";

keypadBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        const val = e.currentTarget.getAttribute('data-val');
        if (val === 'back') {
            enteredPin = enteredPin.slice(0, -1);
        } else if (enteredPin.length < 4) {
            enteredPin += val;
        }
        updateDots();
        
        if (enteredPin.length === 4) {
            // Slight delay so the user sees the 4th dot fill before submitting
            setTimeout(() => submitPin(enteredPin), 50);
        }
    });
});

function updateDots() {
    passcodeDots.forEach((dot, index) => {
        if (index < enteredPin.length) {
            dot.classList.remove('bg-transparent', 'border-gray-500', 'dark:border-gray-400');
            dot.classList.add('bg-gray-800', 'border-gray-800', 'dark:bg-gray-100', 'dark:border-gray-100');
        } else {
            dot.classList.add('bg-transparent', 'border-gray-500', 'dark:border-gray-400');
            dot.classList.remove('bg-gray-800', 'border-gray-800', 'dark:bg-gray-100', 'dark:border-gray-100');
        }
    });
}

// Check Auth State on Load
async function checkAuth() {
    try {
        const res = await fetch('/api/check-auth');
        const data = await res.json();
        if (data.authenticated) {
            initApp();
        }
    } catch (e) {
        console.error("Auth check failed", e);
    }
}
checkAuth();

async function submitPin(pin) {
    try {
        const res = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pin })
        });
        const data = await res.json();
        if (data.success) {
            // Success animation
            loginOverlay.style.opacity = '0';
            setTimeout(() => initApp(), 500);
        } else {
            // Error animation
            const dotContainer = document.getElementById('passcodeDots');
            dotContainer.classList.remove('animate-shake');
            void dotContainer.offsetWidth; // trigger reflow
            dotContainer.classList.add('animate-shake');
            
            // haptic and reset
            playHaptic();
            enteredPin = "";
            setTimeout(updateDots, 400);
        }
    } catch (e) {
        enteredPin = "";
        updateDots();
    }
}

logoutBtn.addEventListener('click', async () => {
    await fetch('/api/logout', { method: 'POST' });
    window.location.reload();
});

// --- Init App ---
function initApp() {
    loginOverlay.classList.add('pointer-events-none', 'hidden');
    appContainer.classList.remove('hidden');
    
    socket = io();
    
    socket.on('connect', () => {
        loadInitialClips();
    });
    
    socket.on('new_clip', (clip) => {
        if (!allClips.find(c => c.id === clip.id)) {
            allClips.unshift(clip);
            updateGloballyUsedTags();
            renderTimeline();
            
            if(document.activeElement !== clipInput && !clip.isLocal) {
                showToast("New item synced");
                playHaptic();
            }
        }
    });

    socket.on('delete_clip', (id) => {
        allClips = allClips.filter(c => c.id != id);
        renderTimeline();
    });
    
    if (localStorage.getItem('clipsync_autosync') === 'true') {
        autoSyncToggle.checked = true;
        startAutoSync();
    }
}

async function loadInitialClips() {
    try {
        const res = await fetch('/api/clips');
        allClips = await res.json();
        updateGloballyUsedTags();
        renderTimeline();
    } catch (e) {
        console.error("Failed to load clips", e);
    }
}

// --- Smart Detection ---
function detectType(content) {
    const txt = content.trim();
    if (/^https?:\/\/[^\s]+$/.test(txt)) return 'url';
    if (txt.includes('{') && txt.includes('}') || txt.includes('function') || txt.includes('=>') || txt.includes('const ') || txt.includes('let ') || txt.includes('import ') || txt.includes('</div>')) {
        return 'code';
    }
    return 'text';
}

function escapeHTML(str) {
    const div = document.createElement('div');
    div.innerText = str;
    return div.innerHTML;
}

// --- Inputs & File Staging ---
clipInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendClip();
    }
});

sendBtn.addEventListener('click', sendClip);

fileUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
        alert("File too large. Max 5MB allowed.");
        fileUpload.value = '';
        return;
    }
    
    stagedFile = file;
    stagedFileName.innerText = file.name;
    stagedFileContainer.classList.remove('hidden');
});

removeStagedFileBtn.addEventListener('click', () => {
    stagedFile = null;
    fileUpload.value = '';
    stagedFileContainer.classList.add('hidden');
});

function sendClip() {
    const content = clipInput.value.trim();
    const activeTagsStr = JSON.stringify(currentTags);
    
    if (stagedFile) {
        const formData = new FormData();
        formData.append('file', stagedFile);
        formData.append('tags', activeTagsStr);
        if (content) {
            formData.append('content', content);
        }
        
        uploadProgress.classList.remove('hidden');
        uploadProgressBar.style.width = '20%';
        
        const req = new XMLHttpRequest();
        req.upload.addEventListener("progress", function (evt) {
            if (evt.lengthComputable) {
                let percentComplete = parseInt((evt.loaded / evt.total) * 100);
                uploadProgressBar.style.width = percentComplete + '%';
            }
        });
        
        req.open("POST", "/api/upload", true);
        req.onload = function() {
            setTimeout(() => {
                uploadProgress.classList.add('hidden');
                uploadProgressBar.style.width = '0%';
                
                stagedFile = null;
                fileUpload.value = '';
                stagedFileContainer.classList.add('hidden');
                clipInput.value = '';
                currentTags = [];
                renderActiveTags();
            }, 500);
        };
        req.send(formData);
        
    } else {
        if (!content) return;
        
        const type = detectType(content);
        socket.emit('add_clip', {
            content,
            type,
            tags: activeTagsStr
        });
        
        clipInput.value = '';
        currentTags = [];
        renderActiveTags();
    }
}

// --- Tag Input handling ---
tagBtn.addEventListener('click', () => {
    tagInputWrapper.classList.toggle('hidden');
    tagInputWrapper.classList.toggle('flex');
    if(!tagInputWrapper.classList.contains('hidden')) tagInput.focus();
});

tagInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        const tag = tagInput.value.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
        if (tag && !currentTags.includes(tag)) {
            currentTags.push(tag);
            renderActiveTags();
        }
        tagInput.value = '';
    }
});

function renderActiveTags() {
    activeTagsContainer.innerHTML = '';
    currentTags.forEach(tag => {
        const el = document.createElement('div');
        el.className = 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 px-3 py-1 text-xs font-semibold rounded-full flex items-center gap-1';
        el.innerHTML = `
            <span>#${tag}</span>
            <button class="hover:text-red-500 ml-1 focus:outline-none" onclick="removeTag('${tag}')">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        `;
        activeTagsContainer.appendChild(el);
    });
}
window.removeTag = (tag) => {
    currentTags = currentTags.filter(t => t !== tag);
    renderActiveTags();
};

// --- Custom Delete Modal ---
let pendingDeleteId = null;

function showDeleteModal(id) {
    pendingDeleteId = id;
    deleteModal.classList.remove('opacity-0', 'pointer-events-none');
    deleteModalContent.classList.remove('scale-95');
    deleteModalContent.classList.add('scale-100');
}

function hideDeleteModal() {
    pendingDeleteId = null;
    deleteModalContent.classList.remove('scale-100');
    deleteModalContent.classList.add('scale-95');
    deleteModal.classList.add('opacity-0', 'pointer-events-none');
}

cancelDeleteBtn.addEventListener('click', hideDeleteModal);
confirmDeleteBtn.addEventListener('click', async () => {
    if (pendingDeleteId) {
        await fetch(`/api/clips/${pendingDeleteId}`, { method: 'DELETE' });
    }
    hideDeleteModal();
});

// --- Render Timeline ---
function updateGloballyUsedTags() {
    globallyUsedTags.clear();
    allClips.forEach(c => {
        try { JSON.parse(c.tags || '[]').forEach(t => globallyUsedTags.add(t)); } catch(e) {}
    });
    renderFilters();
}

function renderFilters() {
    filterContainer.innerHTML = '';
    const allBtn = document.createElement('button');
    allBtn.className = `px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${activeFilter === null ? 'bg-gray-800 text-white dark:bg-gray-200 dark:text-gray-900' : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700'}`;
    allBtn.innerText = 'All';
    allBtn.onclick = () => { activeFilter = null; renderFilters(); renderTimeline(); };
    filterContainer.appendChild(allBtn);
    
    globallyUsedTags.forEach(tag => {
        const btn = document.createElement('button');
        btn.className = `px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${activeFilter === tag ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-400 dark:hover:bg-blue-900/50'}`;
        btn.innerText = '#' + tag;
        btn.onclick = () => { activeFilter = tag; renderFilters(); renderTimeline(); };
        filterContainer.appendChild(btn);
    });
}

function renderTimeline() {
    timeline.innerHTML = '';
    
    let filtered = allClips;
    if (activeFilter) {
        filtered = allClips.filter(c => {
            try { return JSON.parse(c.tags || '[]').includes(activeFilter); } 
            catch(e) { return false; }
        });
    }
    
    if (filtered.length === 0) {
        timeline.appendChild(emptyState);
        emptyState.classList.remove('hidden');
        return;
    }
    emptyState.classList.add('hidden');
    
    filtered.forEach(clip => {
        const d = new Date(clip.timestamp);
        const timeStr = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        let parsedTags = [];
        try { parsedTags = JSON.parse(clip.tags || '[]'); } catch(e){}
        const tagHTML = parsedTags.map(t => `<span class="text-xs font-semibold text-blue-500 mr-2">#${t}</span>`).join('');

        let contentHTML = '';
        const isLongText = clip.content.length > 300 || clip.content.split('\n').length > 6;
        const clampWrapperStart = isLongText ? `<div class="content-clamp w-full">` : `<div class="w-full">`;
        const clampWrapperEnd = `</div>`;
        
        // Expand icon logic replacing text button
        const expandIconHTML = isLongText ? `
            <button class="expand-btn p-1.5 text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors" title="Expand View">
                <svg class="w-4 h-4 expand-svg" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path></svg>
                <svg class="w-4 h-4 collapse-svg hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 14h4v4m0-4l-5 5M20 10h-4V6m0 4l5-5M4 10h4V6m0 4l-5-5m16 4h-4v4m0-4l5 5"></path></svg>
            </button>
        ` : '';
        
        const actualFileName = clip.file_path ? clip.file_path.split('/').pop().replace(/^\d+-/, '') : "file";
        const hasCustomText = clip.content && clip.content !== actualFileName;

        if (clip.type === 'url') {
            contentHTML = `
                <div class="flex items-center gap-3 bg-gray-50 dark:bg-gray-900/50 p-3 rounded-xl border border-gray-100 dark:border-gray-800">
                    <div class="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center rounded-lg flex-shrink-0">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                    </div>
                    <div class="overflow-hidden">
                        <a href="${clip.content}" target="_blank" class="text-blue-600 dark:text-blue-400 font-medium hover:underline truncate block">${escapeHTML(clip.content)}</a>
                    </div>
                </div>`;
        } else if (clip.type === 'file') {
            const isImage = clip.file_path && clip.file_path.match(/\.(jpeg|jpg|gif|png|webp)$/i);
            
            if (isImage) {
                contentHTML = `
                ${hasCustomText ? `<div class="mb-3 text-gray-800 dark:text-gray-200">${escapeHTML(clip.content)}</div>` : ''}
                <div class="relative group rounded-xl overflow-hidden bg-gray-100 dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                    <img src="${clip.file_path}" alt="Image payload" class="max-h-64 object-contain mx-auto w-full">
                    <a href="${clip.file_path}" download="${actualFileName}" class="absolute bottom-2 right-2 p-2 bg-black/60 backdrop-blur text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    </a>
                </div>`;
            } else {
                contentHTML = `
                ${hasCustomText ? `<div class="mb-3 text-gray-800 dark:text-gray-200">${escapeHTML(clip.content)}</div>` : ''}
                <div class="flex items-center justify-between bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
                    <div class="flex items-center gap-3 overflow-hidden">
                        <svg class="w-8 h-8 text-indigo-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                        <p class="font-medium text-gray-800 dark:text-gray-200 truncate">${escapeHTML(actualFileName)}</p>
                    </div>
                    <a href="${clip.file_path}" download="${actualFileName}" class="p-2 bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 rounded-lg hover:bg-indigo-200 dark:hover:bg-indigo-900/50 transition-colors flex-shrink-0">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    </a>
                </div>`;
            }
        } else if (clip.type === 'code') {
            contentHTML = `
                <div class="rounded-xl overflow-hidden shadow-inner font-mono text-sm relative w-full">
                    ${clampWrapperStart}
                        <pre><code class="language-javascript">${escapeHTML(clip.content)}</code></pre>
                    ${clampWrapperEnd}
                </div>`;
        } else {
            // plain text
            contentHTML = `
                <div class="p-4 bg-gray-50 dark:bg-gray-900/30 rounded-xl font-sans text-gray-700 dark:text-gray-300 border border-transparent hover:border-gray-200 dark:hover:border-gray-800 transition-colors relative w-full">
                    ${clampWrapperStart}
                        <div class="whitespace-pre-wrap">${escapeHTML(clip.content)}</div>
                    ${clampWrapperEnd}
                </div>`;
        }

        const card = document.createElement('div');
        card.className = "clip-card pl-8 relative group";
        card.id = `clip-${clip.id}`;
        
        // Node marker
        const marker = document.createElement('div');
        marker.className = "absolute left-[-5px] top-4 w-3 h-3 rounded-full border-2 border-white dark:border-darkBg bg-blue-500 shadow z-10";
        card.appendChild(marker);

        card.innerHTML += `
            <div class="bg-white dark:bg-darkCard rounded-2xl p-1 shadow-sm border border-gray-100 dark:border-gray-800 transition-shadow hover:shadow-md">
                <div class="p-3 sm:px-4 flex items-center justify-between border-b border-gray-50 dark:border-gray-800/50">
                    <div class="flex items-center gap-2">
                        <span class="text-xs text-gray-400 font-medium">${timeStr}</span>
                        ${clip.type !== 'text' ? `<span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded text-gray-500 bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">${clip.type}</span>` : ''}
                    </div>
                    <!-- Action Bar -->
                    <div class="opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 items-center">
                        ${expandIconHTML}
                        <button class="copyBtn p-1.5 text-gray-400 hover:text-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors" data-content="${escapeHTML(clip.content)}" title="Copy">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                        </button>
                        <button class="deleteBtn p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors" data-id="${clip.id}" title="Delete">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    </div>
                </div>
                <div class="p-3 sm:px-4 w-full overflow-hidden">
                    ${contentHTML}
                    ${tagHTML ? `<div class="mt-3 flex gap-1">${tagHTML}</div>` : ''}
                </div>
            </div>
        `;
        
        timeline.appendChild(card);
    });

    if (window.Prism) Prism.highlightAll();

    // Attach local events
    document.querySelectorAll('.copyBtn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const val = e.currentTarget.getAttribute('data-content');
            const txt = new DOMParser().parseFromString(val, "text/html").documentElement.textContent;
            navigator.clipboard.writeText(txt).then(() => {
                showToast('Copied to clipboard!');
                const cardWrap = e.currentTarget.closest('.bg-white');
                cardWrap.classList.add('copy-success');
                setTimeout(() => cardWrap.classList.remove('copy-success'), 1000);
            });
        });
    });

    document.querySelectorAll('.deleteBtn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = e.currentTarget.getAttribute('data-id');
            showDeleteModal(id);
        });
    });

    document.querySelectorAll('.expand-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Traverse up to find the clip card wrapper, then drill down to clamp content
            const cardRoot = e.currentTarget.closest('.clip-card');
            const wrapper = cardRoot.querySelector('.content-clamp') || cardRoot.querySelector('.content-expanded');
            
            const expandSvg = e.currentTarget.querySelector('.expand-svg');
            const collapseSvg = e.currentTarget.querySelector('.collapse-svg');

            if (wrapper && wrapper.classList.contains('content-clamp')) {
                wrapper.classList.remove('content-clamp');
                wrapper.classList.add('content-expanded');
                expandSvg.classList.add('hidden');
                collapseSvg.classList.remove('hidden');
            } else if (wrapper) {
                wrapper.classList.add('content-clamp');
                wrapper.classList.remove('content-expanded');
                expandSvg.classList.remove('hidden');
                collapseSvg.classList.add('hidden');
            }
        });
    });
}

function showToast(msg) {
    toastMsg.innerText = msg;
    toast.classList.remove('translate-y-20', 'opacity-0');
    setTimeout(() => toast.classList.add('translate-y-20', 'opacity-0'), 3000);
}

function playHaptic() {
    if (navigator.vibrate) navigator.vibrate(50);
}

// --- Auto Sync ---
let autoSyncInterval;
let lastClipboardHash = '';

autoSyncToggle.addEventListener('change', (e) => {
    localStorage.setItem('clipsync_autosync', e.target.checked);
    if (e.target.checked) {
        startAutoSync();
        showToast("Auto Sync enabled.");
    } else {
        stopAutoSync();
    }
});

async function startAutoSync() {
    if (!navigator.clipboard || !navigator.clipboard.readText) return;
    try { lastClipboardHash = hashCode(await navigator.clipboard.readText()); } catch(e) {}
    autoSyncInterval = setInterval(async () => {
        if (document.hidden) return;
        try {
            const txt = await navigator.clipboard.readText();
            if (!txt) return;
            const hash = hashCode(txt);
            if (hash !== lastClipboardHash) {
                lastClipboardHash = hash;
                if (allClips.length > 0 && allClips[0].content === txt) return;
                socket.emit('add_clip', { content: txt, type: detectType(txt), tags: "[]" });
                showToast("Auto-synced from local clipboard");
            }
        } catch(e) {}
    }, 3000);
}

function stopAutoSync() {
    if (autoSyncInterval) clearInterval(autoSyncInterval);
}

function hashCode(str) {
    let hash = 0;
    for (let i = 0, len = str.length; i < len; i++) {
        hash = (hash << 5) - hash + str.charCodeAt(i);
        hash |= 0;
    }
    return hash;
}
